package com.ifinah;

public class H1BVisaRecord {
	/* Standard Set of Fields From Headers
	 * This is the Base Format for Data Processing 
	 * If the Data is in any format that is correct 
	 * We should be able to get these indices  
	 * See possible fields to filter with below. 

	public H1BVisaRecord(String[] flds) {
		setCase_number(flds[1]);
		setCase_status(flds[2]);
		setVisa_class(flds[5]);
		setEmployer_state(flds[11]);
		setJob_title(flds[20]);
		setSoc_name(flds[22]);
//		setWorksite_state(flds[50]);

	}


	static String[] relevantFldNames = {"CASE_NUMBER", "CASE_STATUS", "VISA_CLASS", 
		"JOB_TITLE", "SOC_NAME", "EMPLOYER_STATE", "TOTAL_WORKERS"};
	static int [] relevantIndices = {1,2,5,20,22,11,50}; // Default values
	*/
	
	public H1BVisaRecord(String[] flds, int[] indices) {
		setCase_number(flds[indices[0]]);
		setCase_status(flds[indices[1]]);
		setVisa_class(flds[indices[2]]);
		setJob_title(flds[indices[3]]);
		setSoc_name(flds[indices[4]]);
		setEmployer_state(flds[indices[5]]);
		if (indices[6] > 0)
			setWorksite_state(flds[indices[6]]);

	}
	
	String 

	case_number,
	case_status,
	case_submitted,
	decision_date,
	visa_class,
	employment_start_date,
	employment_end_date,
	employer_name,
	employer_business_dba,
	employer_address,
	employer_city,
	employer_state,
	employer_postal_code,
	employer_country,
	employer_province,
	employer_phone,
	employer_phone_ext,
	agent_representing_employer,
	agent_attorney_name,
	agent_attorney_city,
	agent_attorney_state,
	job_title,
	soc_code,
	soc_name,
	naics_code,

	new_employment,
	continued_employment,
	change_previous_employment,
	new_concurrent_emp,
	change_employer,
	amended_petition,
	full_time_position,

	pw_unit_of_pay,
	pw_wage_level,
	pw_source,
	pw_source_year,
	pw_source_other,

	wage_unit_of_pay,
	h1b_dependent,
	willful_violator,
	support_h1b,
	labor_con_agree,
	public_disclosure_location,
	worksite_city,
	worksite_county,
	worksite_state,
	worksite_postal_code,
	original_cert_date;
	Integer total_workers;

	String prevailing_wage;
	String wage_rate_of_pay_from;
	String wage_rate_of_pay_to;
	public String getCase_number() {
		return case_number;
	}
	public void setCase_number(String case_number) {
		this.case_number = case_number;
	}
	public String getCase_status() {
		return case_status;
	}
	public void setCase_status(String case_status) {
		this.case_status = case_status;
	}
	public String getCase_submitted() {
		return case_submitted;
	}
	public void setCase_submitted(String case_submitted) {
		this.case_submitted = case_submitted;
	}
	public String getDecision_date() {
		return decision_date;
	}
	public void setDecision_date(String decision_date) {
		this.decision_date = decision_date;
	}
	public String getVisa_class() {
		return visa_class;
	}
	public void setVisa_class(String visa_class) {
		this.visa_class = visa_class;
	}
	public String getEmployment_start_date() {
		return employment_start_date;
	}
	public void setEmployment_start_date(String employment_start_date) {
		this.employment_start_date = employment_start_date;
	}
	public String getEmployment_end_date() {
		return employment_end_date;
	}
	public void setEmployment_end_date(String employment_end_date) {
		this.employment_end_date = employment_end_date;
	}
	public String getEmployer_name() {
		return employer_name;
	}
	public void setEmployer_name(String employer_name) {
		this.employer_name = employer_name;
	}
	public String getEmployer_business_dba() {
		return employer_business_dba;
	}
	public void setEmployer_business_dba(String employer_business_dba) {
		this.employer_business_dba = employer_business_dba;
	}
	public String getEmployer_address() {
		return employer_address;
	}
	public void setEmployer_address(String employer_address) {
		this.employer_address = employer_address;
	}
	public String getEmployer_city() {
		return employer_city;
	}
	public void setEmployer_city(String employer_city) {
		this.employer_city = employer_city;
	}
	public String getEmployer_state() {
		return employer_state;
	}
	public void setEmployer_state(String employer_state) {
		this.employer_state = employer_state;
	}
	public String getEmployer_postal_code() {
		return employer_postal_code;
	}
	public void setEmployer_postal_code(String employer_postal_code) {
		this.employer_postal_code = employer_postal_code;
	}
	public String getEmployer_country() {
		return employer_country;
	}
	public void setEmployer_country(String employer_country) {
		this.employer_country = employer_country;
	}
	public String getEmployer_province() {
		return employer_province;
	}
	public void setEmployer_province(String employer_province) {
		this.employer_province = employer_province;
	}
	public String getEmployer_phone() {
		return employer_phone;
	}
	public void setEmployer_phone(String employer_phone) {
		this.employer_phone = employer_phone;
	}
	public String getEmployer_phone_ext() {
		return employer_phone_ext;
	}
	public void setEmployer_phone_ext(String employer_phone_ext) {
		this.employer_phone_ext = employer_phone_ext;
	}
	public String getAgent_representing_employer() {
		return agent_representing_employer;
	}
	public void setAgent_representing_employer(String agent_representing_employer) {
		this.agent_representing_employer = agent_representing_employer;
	}
	public String getAgent_attorney_name() {
		return agent_attorney_name;
	}
	public void setAgent_attorney_name(String agent_attorney_name) {
		this.agent_attorney_name = agent_attorney_name;
	}
	public String getAgent_attorney_city() {
		return agent_attorney_city;
	}
	public void setAgent_attorney_city(String agent_attorney_city) {
		this.agent_attorney_city = agent_attorney_city;
	}
	public String getAgent_attorney_state() {
		return agent_attorney_state;
	}
	public void setAgent_attorney_state(String agent_attorney_state) {
		this.agent_attorney_state = agent_attorney_state;
	}
	public String getJob_title() {
		return job_title;
	}
	public void setJob_title(String job_title) {
		this.job_title = job_title;
	}
	public String getSoc_code() {
		return soc_code;
	}
	public void setSoc_code(String soc_code) {
		this.soc_code = soc_code;
	}
	public String getSoc_name() {
		return soc_name;
	}
	public void setSoc_name(String soc_name) {
		this.soc_name = soc_name;
	}
	public String getNaics_code() {
		return naics_code;
	}
	public void setNaics_code(String naics_code) {
		this.naics_code = naics_code;
	}
	public String getNew_employment() {
		return new_employment;
	}
	public void setNew_employment(String new_employment) {
		this.new_employment = new_employment;
	}
	public String getContinued_employment() {
		return continued_employment;
	}
	public void setContinued_employment(String continued_employment) {
		this.continued_employment = continued_employment;
	}
	public String getChange_previous_employment() {
		return change_previous_employment;
	}
	public void setChange_previous_employment(String change_previous_employment) {
		this.change_previous_employment = change_previous_employment;
	}
	public String getNew_concurrent_emp() {
		return new_concurrent_emp;
	}
	public void setNew_concurrent_emp(String new_concurrent_emp) {
		this.new_concurrent_emp = new_concurrent_emp;
	}
	public String getChange_employer() {
		return change_employer;
	}
	public void setChange_employer(String change_employer) {
		this.change_employer = change_employer;
	}
	public String getAmended_petition() {
		return amended_petition;
	}
	public void setAmended_petition(String amended_petition) {
		this.amended_petition = amended_petition;
	}
	public String getFull_time_position() {
		return full_time_position;
	}
	public void setFull_time_position(String full_time_position) {
		this.full_time_position = full_time_position;
	}
	public String getPw_unit_of_pay() {
		return pw_unit_of_pay;
	}
	public void setPw_unit_of_pay(String pw_unit_of_pay) {
		this.pw_unit_of_pay = pw_unit_of_pay;
	}
	public String getPw_wage_level() {
		return pw_wage_level;
	}
	public void setPw_wage_level(String pw_wage_level) {
		this.pw_wage_level = pw_wage_level;
	}
	public String getPw_source() {
		return pw_source;
	}
	public void setPw_source(String pw_source) {
		this.pw_source = pw_source;
	}
	public String getPw_source_year() {
		return pw_source_year;
	}
	public void setPw_source_year(String pw_source_year) {
		this.pw_source_year = pw_source_year;
	}
	public String getPw_source_other() {
		return pw_source_other;
	}
	public void setPw_source_other(String pw_source_other) {
		this.pw_source_other = pw_source_other;
	}
	public String getWage_unit_of_pay() {
		return wage_unit_of_pay;
	}
	public void setWage_unit_of_pay(String wage_unit_of_pay) {
		this.wage_unit_of_pay = wage_unit_of_pay;
	}
	public String getH1b_dependent() {
		return h1b_dependent;
	}
	public void setH1b_dependent(String h1b_dependent) {
		this.h1b_dependent = h1b_dependent;
	}
	public String getWillful_violator() {
		return willful_violator;
	}
	public void setWillful_violator(String willful_violator) {
		this.willful_violator = willful_violator;
	}
	public String getSupport_h1b() {
		return support_h1b;
	}
	public void setSupport_h1b(String support_h1b) {
		this.support_h1b = support_h1b;
	}
	public String getLabor_con_agree() {
		return labor_con_agree;
	}
	public void setLabor_con_agree(String labor_con_agree) {
		this.labor_con_agree = labor_con_agree;
	}
	public String getPublic_disclosure_location() {
		return public_disclosure_location;
	}
	public void setPublic_disclosure_location(String public_disclosure_location) {
		this.public_disclosure_location = public_disclosure_location;
	}
	public String getWorksite_city() {
		return worksite_city;
	}
	public void setWorksite_city(String worksite_city) {
		this.worksite_city = worksite_city;
	}
	public String getWorksite_county() {
		return worksite_county;
	}
	public void setWorksite_county(String worksite_county) {
		this.worksite_county = worksite_county;
	}
	public String getWorksite_state() {
		return worksite_state;
	}
	public void setWorksite_state(String worksite_state) {
		this.worksite_state = worksite_state;
	}
	public String getWorksite_postal_code() {
		return worksite_postal_code;
	}
	public void setWorksite_postal_code(String worksite_postal_code) {
		this.worksite_postal_code = worksite_postal_code;
	}
	public String getOriginal_cert_date() {
		return original_cert_date;
	}
	public void setOriginal_cert_date(String original_cert_date) {
		this.original_cert_date = original_cert_date;
	}
	public Integer getTotal_workers() {
		return total_workers;
	}
	public void setTotal_workers(Integer total_workers) {
		this.total_workers = total_workers;
	}
	public String getPrevailing_wage() {
		return prevailing_wage;
	}
	public void setPrevailing_wage(String prevailing_wage) {
		this.prevailing_wage = prevailing_wage;
	}
	public String getWage_rate_of_pay_from() {
		return wage_rate_of_pay_from;
	}
	public void setWage_rate_of_pay_from(String wage_rate_of_pay_from) {
		this.wage_rate_of_pay_from = wage_rate_of_pay_from;
	}
	public String getWage_rate_of_pay_to() {
		return wage_rate_of_pay_to;
	}
	public void setWage_rate_of_pay_to(String wage_rate_of_pay_to) {
		this.wage_rate_of_pay_to = wage_rate_of_pay_to;
	}

}
