package com.ifinah;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

public class H1BVisas {
	/*  Main Class for H1Bvisa Sorting Data 
	 * 
	 * Create input and ouput folders in proper Directory
	 * Pass @Path for all input files (.csv and .txt file types) 
	 * 
	 */
	// Create input and ouput folders for 
	
	public static String inputFolder = System.getProperty("user.dir", System.getProperty("user.home")).
			concat(File.separator).concat("input");
	public static String outputFolder = System.getProperty("user.dir", System.getProperty("user.home")).
			concat(File.separator).concat("output");;
			
	public static void main(String[] args) {
		
		String folder = inputFolder;  // Default location for me. For the final version running thru shell script, it should be input.
		if (args.length > 1) {
			folder = args[1];
		}
		
		
		File ff = new File(folder);
		if (!ff.exists()) {
			ff.mkdir();
			System.out.println("Please copy the input file into " + folder);
		}
		
		File[] files = null;
		
		if (ff.isDirectory())
			files = ff.listFiles();
		
		 
	//	System.getProperties().list(System.out);
		try {
			if (files != null) {
				for (int cnt=0; cnt<files.length; cnt++) {
					if (!files[cnt].toString().contains(".DS_Store"))
						ProcessCSVFile.readFile(files[cnt].toPath());
				}

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
