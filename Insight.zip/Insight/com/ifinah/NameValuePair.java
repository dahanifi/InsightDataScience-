package com.ifinah;

import java.io.Serializable;
/**
 * A class representing the name/value pair object with the additional fields for grouping the fields and
 * sorting the entries.
 *
 */
public class NameValuePair implements Serializable {

	static final long serialVersionUID = 03122007L;
	String name;
	int value;
	 
	public NameValuePair() {}
	public NameValuePair(String name, int value) {
	
		this.name = name;
		this.value = value;
		 
	}

	 
	public String getName() { return (name); }
	 

	public void setName(String name) {
		this.name = name;
	}
	
	public int getValue() {
		return (value);
	}
	
	public String getStringValue() {
		return (new Integer(value).toString());
	}
	public void setValue(int value) {
		this.value = value;
	}
}
