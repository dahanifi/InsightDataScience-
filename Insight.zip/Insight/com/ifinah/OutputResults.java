package com.ifinah;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class OutputResults {
/* A output Class where sorting
 * This Outputs sorted CSV from all data contained in input folder
 * Sorted and Output into the proper Directory
 * If you want more Sort fields add them here 
 * Build sort conditions in this folder call them here 
 * Debugging Scripts Commented out Below if Needed 
 */
	public static void ouputStatBySoc_name(List<H1BVisaRecord> al, int totalSize, String oFile) {
		Collections.sort(al, new SortBySoc_name());	
		
		/* For Debugging Purposes Completeness of Data
		 * 
		 * System.out.println();
		 for (H1BVisaRecord v : al) {
			 System.out.println(v.getSoc_name());
		 }
		 */
		
		List<NameValuePair> list = getTop_Soc_names(al);
		Collections.sort(list, new SortByNameValue(true));

		int cnt = 0;

		StringBuffer sb = new StringBuffer();
		sb.append(String.format("%s%n%n", "TOP_OCCUPATIONS;NUMBER_CERTIFIED_APPLICATIONS;PERCENTAGE"));//Add OuputHeader
		for (NameValuePair nv : list) {
			if (cnt < 10) cnt++;
			else break;
			double db = (((double)nv.getValue()/(double)totalSize) * 100.0);
			String result = String.format("%s;%02d;%3.1f%n", nv.getName(), nv.getValue(), db);
			
			sb.append(result);
		
		// For Debugging output prints results  (as opposed to output as file)
		//	System.out.println(result);
			
		} 
		try {
			Path p = Paths.get(oFile);
			boolean exists = Files.exists(p, new LinkOption[] { LinkOption.NOFOLLOW_LINKS }); // CleanUp/Create Output
			if (exists) Files.delete(p);
			 
			Files.write(p, sb.toString().getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	static private List<NameValuePair> getTop_Soc_names(List<H1BVisaRecord> al) {
		String soc_name = al.get(0).getSoc_name();
		int cnt = 0;
		boolean add2list = false;
		ArrayList<NameValuePair> nvlist = new ArrayList<NameValuePair>();
		for (H1BVisaRecord v : al) {

			if (v.getSoc_name().equalsIgnoreCase(soc_name)) {
				cnt ++;
				add2list = true;
			} else {
				nvlist.add(new NameValuePair(soc_name, cnt));
				add2list = false;
				cnt = 1;
				soc_name = v.getSoc_name();
			}	

		}
		if (add2list)
			nvlist.add(new NameValuePair(soc_name, cnt));
		return nvlist;
	}
	
	
	

	
	
	
	
	
	public static void ouputEmployer_state(List<H1BVisaRecord> al, int totalSize, String oFile) {
		Collections.sort(al, new SortByEmployer_state());	
		
		/* For Debugging Purposes Completeness of Data
		 * 
		 * System.out.println();
		 for (H1BVisaRecord v : al) {
			 System.out.println(v.getTop_Employer_state());
		 }
		 */
		
		
		List<NameValuePair> list = getTop_Employer_state(al);
		Collections.sort(list, new SortByNameValue(true));

		int cnt = 0;

		StringBuffer sb = new StringBuffer();
		sb.append(String.format("%s%n%n", "\r\n" + "TOP_STATES;NUMBER_CERTIFIED_APPLICATIONS;PERCENTAGE"));//Add OuputHeader
		for (NameValuePair nv : list) {
			if (cnt < 10) cnt++;
			else break;
			double db = (((double)nv.getValue()/(double)totalSize) * 100.0);
			String result = String.format("%s;%02d;%3.1f%n", nv.getName(), nv.getValue(), db);
			
			sb.append(result);
			
		// For Debugging output prints results (as opposed to output as file)
		//	System.out.println(result); 
		} 
		try {
			Path p = Paths.get(oFile);
			boolean exists = Files.exists(p, new LinkOption[] { LinkOption.NOFOLLOW_LINKS }); // CleanUp/Create Output
			if (exists) Files.delete(p);
			 
			Files.write(p, sb.toString().getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	static private List<NameValuePair> getTop_Employer_state(List<H1BVisaRecord> al) {
		String employer_state = al.get(0).getEmployer_state();
		int cnt = 0;
		boolean add2list = false;
		ArrayList<NameValuePair> nvlist = new ArrayList<NameValuePair>();
		for (H1BVisaRecord v : al) {
			if (v.getEmployer_state().equalsIgnoreCase(employer_state)) {
				cnt ++;
				add2list = true;
			} else {
				nvlist.add(new NameValuePair(employer_state, cnt));
				add2list = false;
				cnt = 1;
				employer_state = v.getEmployer_state();
			}	
		
		}
		if (add2list)
			nvlist.add(new NameValuePair(employer_state, cnt));
		return nvlist;
	}	
	
}
