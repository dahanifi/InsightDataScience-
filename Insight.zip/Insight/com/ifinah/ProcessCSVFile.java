package com.ifinah;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProcessCSVFile {
	/** 
	 * Reads a File into a List of Strings
	 * 
	 * @param aFileName
	 * @return List<String>
	 * @throws IOException
	 */
	
	static String[] relevantFldNames = {"CASE_NUMBER", "CASE_STATUS", "VISA_CLASS", 
		"JOB_TITLE", "SOC_NAME", "EMPLOYER_STATE", "TOTAL_WORKERS"};
	 
// Default Values: If you are using this, the input file header are incorrect like H1B_FY_2014 
// This means the output will probably be wrong, because names of 
// The header fields are inconsistent/incorrect year to year. This outlier lend itself to general code
	
	static int [] relevantIndices = {1,2,5,20,22,11,0}; // Default values
	
	
														
	
	static public List<String> readFile(Path path) throws IOException {	
		List<String> contents = Files.readAllLines(path, StandardCharsets.UTF_8);   // Read in data
		ArrayList<H1BVisaRecord> al = null;
		if (contents != null && contents.size() > 0) {
			al = new ArrayList<H1BVisaRecord>();
			boolean first = true;
			String[] hdrs = null;
			
			for (String line: contents) {
					if (first) {
						hdrs = line.trim().split(";"); 
					
						setRelevantIndices(hdrs);
						
						first = false;
						continue;  // the first line
					} // Pull Lines with ;CERTIFIED; only 
					if (line.contains(";CERTIFIED;")) {   
						line = line.replaceAll("&AMP;", "");
						line = line.replaceAll("\"",""); // Remove the "" from the file for Sorting purposes
						String[]flds = line.trim().split(";");
						H1BVisaRecord h1b = new H1BVisaRecord(flds,relevantIndices);// Fields
						al.add(h1b);		
					 
						// 
					}
				}
			
			File of = new File(H1BVisas.outputFolder);
			if (!of.exists()) {
				of.mkdir();
			}
			// Create output file names for final data Top Employer by State and Top Job Title 
			
			String oFile = H1BVisas.outputFolder.concat(File.separator).concat("top_10_occupation_").concat(path.getFileName().toString());
			String o2File = H1BVisas.outputFolder.concat(File.separator).concat("top_10_states_").concat(path.getFileName().toString());
			
			//Place new Output String o3file here. 
			
			
		
			// Output Call for Data your Wish to Sort Soc_Name and State in this case  

			 OutputResults.ouputStatBySoc_name(al, al.size(), oFile);
			 OutputResults.ouputEmployer_state(al, al.size(), o2File);
			 
			 // If you want a new OutputResults.method here is the place to put it after you write it i.e.
			 // OutputResults.ouputJob_title(al,al.size(),o3File); 
		}
		return null;
	}
	//Sets dynamic indices into array for headers (if they shift from year to year) 
	static void setRelevantIndices(String[] hdrs) { // , int[] relevantIndices) {
		for (int i=0; i<relevantFldNames.length; i++) {
			int index = getIndex(hdrs, relevantFldNames[i]);
			if (index != relevantIndices[i] && index > 0) {
				relevantIndices[i] = index;
			}
		}
		
	}
	static int getIndex(String [] hdrs, String hName) {
		for (int i=0; i<hdrs.length; i++) {
			if (hName.equalsIgnoreCase(hdrs[i])) {
				return i;
			}
		}
		return 0;
	}
}
