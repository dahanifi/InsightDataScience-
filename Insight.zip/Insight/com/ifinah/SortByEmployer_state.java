package com.ifinah;

import java.util.Comparator;
// Basic Sort For State 
public class SortByEmployer_state implements Comparator<H1BVisaRecord>{
	
		boolean descending = false; 

		public SortByEmployer_state(boolean descending) { 
			this.descending = descending;	 
		}
		public SortByEmployer_state() {}
		public int compare(H1BVisaRecord arg0, H1BVisaRecord arg1) {

			try {
				 
				return(arg0.getEmployer_state().compareTo(arg1.getEmployer_state())); 
				
			} catch (Throwable ie) {
				ie.printStackTrace();
			}
		    return(0);
		}
	
	}

