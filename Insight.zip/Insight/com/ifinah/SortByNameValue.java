package com.ifinah;

import java.util.Comparator;
//Basic Sort for Name (if you need it) 
public class SortByNameValue implements Comparator<NameValuePair> {
	
	boolean descending = true;
	
	public SortByNameValue(boolean descending) {
		this.descending = descending;
	}
	
	public int compare(NameValuePair arg0, NameValuePair arg1) {
			
		try {
			boolean eql = arg0.getValue() == arg1.getValue();
			if (eql) {
				return(arg0.getName().compareTo(arg1.getName()));
			} else if (descending) {
				return((arg0.getValue() > arg1.getValue()) ? -1 : 1);
			}
			
		} catch (Throwable ie) {
			ie.printStackTrace();
		}
	    return(0);
	}
}
