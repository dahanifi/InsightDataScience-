package com.ifinah;

import java.util.Comparator;
// Basic Sort for Name
public class SortBySoc_name implements Comparator<H1BVisaRecord>{
	
		boolean descending = false; 

		public SortBySoc_name(boolean descending) { 
			this.descending = descending;	 
		}
		public SortBySoc_name() {}
		public int compare(H1BVisaRecord arg0, H1BVisaRecord arg1) {

			try {
				 
				return(arg0.getSoc_name().compareTo(arg1.getSoc_name())); 
				
			} catch (Throwable ie) {
				ie.printStackTrace();
			}
		    return(0);
		}
	
	}

