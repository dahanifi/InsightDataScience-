chmod +x run.sh
java com/ifinah/H1BVisas

if [ $? -ne 0 ]
then
   # 
   echo "failure".
   exit 3 
fi
   echo "sucess"
# Terminate our shell script with success message i.e. backup done!
exit 0